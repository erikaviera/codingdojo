$(document).ready(function () {

    /* Cambio de imagen de fondo */

    $('.beach').click(function () {
        $('body').css('background-image', 'url(images/beach.jpg)');
    });
    $('.planet').click(function () {
        $('body').css('background-image', 'url(images/earth.jpg)');
    });
    $('.dojo').click(function () {
        $('body').css('background-image', 'url(images/dojo.jpg)');
    });
    $('.forest').click(function () {
        $('body').css('background-image', 'url(images/forest.jpg)');
    });
    $('.matrix').click(function () {
        $('body').css('background-image', 'url(images/matrix.jpg)');
    });
    $('.snow').click(function () {
        $('body').css('background-image', 'url(images/snow.jpg)');
    });

    /* Oculto selección de arena y muestro select de players */

    $('#select-arena li').click(function () {
        $("div.arena").hide();
        $("div.players").show();
    });

    /* Oculto div que muestra los avatars de los players */

    $("div.players").hide();

    /* Muestro los players seleccionados */

    $('#player1').on('change', function () {
        var character = $(this).val();
        $("div.character1").hide();
        $("#show1" + character).show();
    });

    $('#player2').on('change', function () {
        var character = $(this).val();
        $("div.character2").hide();
        $("#show2" + character).show();
    });

});    
